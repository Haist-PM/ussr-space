import assert from 'node:assert/strict';
import {writeFile,readFile} from 'node:fs/promises';
import * as T from 'three';
import {sceneBlend,craftComposition,planetComposition,transitionDistance,mirAssembly} from '../../src/story-state.js';
import {starCatalog,starAlpha} from '../../src/starfield.js';
import {modelBounds,fitDistance} from '../../src/interaction.js';
import {mars3} from '../../src/models.js';
const report={browserTested:false,scroll:[],transitions:0,marsFraming:0,stars:{}};
for(const height of [540,568,768,844,1080]){const travel=1.45*height,span=transitionDistance(height)/travel;const onset=.3*transitionDistance(height),finish=transitionDistance(height);assert.ok(finish-onset>=height*.6);assert.ok(travel-finish>=height*.4);report.scroll.push({height,transitionPixels:finish,appearancePixels:finish-onset,holdPixels:travel-finish});
 for(const [kind,count] of Object.entries({moon:6,venus:4,mars:4,human:3,stations:4}))for(let stage=1;stage<count;stage++){
  const before=sceneBlend(kind,stage-1,1,false,span),after=sceneBlend(kind,stage,0,false,span);assert.deepEqual(before.weights,after.weights);assert.equal(before.close,after.close);
  let previous;for(let i=0;i<=200;i++){const t=i/200,b=sceneBlend(kind,stage,t*span,false,span);assert.ok(Object.keys(b.weights).length<=1);assert.deepEqual(b,sceneBlend(kind,stage,t*span,false,span));
   if(previous){assert.ok(Math.abs(previous.close-b.close)<.009);for(const key of new Set([...Object.keys(b.weights),...Object.keys(previous.weights)]))assert.ok(Math.abs((b.weights[key]||0)-(previous.weights[key]||0))<.017)}previous=b;
   if(['moon','venus','mars'].includes(kind)){const planet=planetComposition(b.close);for(const weight of Object.values(b.weights)){if(weight<.001)continue;const craft=craftComposition(weight);assert.ok(Math.hypot(planet.y-craft.y,planet.z-craft.z)>planet.scale*2+craft.scale*2,'intersecting bodies');}}
  }report.transitions++;
 }
}
// Landing uses two fixed compositions, independent of the changing visible canopy bounds.
const object=mars3(),land=modelBounds(object.root);object.parachute.visible=true;const descent=modelBounds(object.root),rig=new T.Group(),center=new T.Group();rig.add(center);center.add(object.root);
for(let i=0;i<=100;i++){const amount=i/100;object.parachute.visible=amount>.001;object.parachute.scale.setScalar(Math.max(.001,amount));object.parachute.position.y=2.4*amount;object.petals.visible=amount<.999;object.petals.scale.setScalar(1-.7*amount);center.position.copy(land.center).lerp(descent.center,amount).negate();rig.scale.setScalar(2/T.MathUtils.lerp(land.radius,descent.radius,amount));
 for(const [w,h] of [[1000,800],[636,300],[390,270],[390,135]])for(const angle of [0,.9,2.6]){rig.rotation.set(.3,angle,.2);rig.updateMatrixWorld(true);const camera=new T.PerspectiveCamera(38,w/h,.05,100),d=Math.max(8.4,fitDistance(2.02,w/h));camera.position.set(0,Math.sin(.055)*d,Math.cos(.055)*d);camera.lookAt(0,0,0);camera.updateMatrixWorld(true);
 object.root.traverse(mesh=>{if(!mesh.isMesh||mesh.userData.hotspot)return;for(let p=mesh;p;p=p.parent)if(!p.visible)return;mesh.geometry.computeBoundingBox();const box=mesh.geometry.boundingBox;for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){const p=new T.Vector3(x,y,z).applyMatrix4(mesh.matrixWorld).project(camera);assert.ok(Math.abs(p.x)<.95&&Math.abs(p.y)<.95,'Mars landing clips');}});report.marsFraming++;
 }
}
const stars=starCatalog();assert.deepEqual(stars,starCatalog());assert.ok(stars.filter(s=>s.twinkle).length<stars.length*.22);for(const star of stars){assert.ok(star.period>=4&&star.period<=10);for(let t=0;t<12;t+=.1){const alpha=starAlpha(star,t);assert.ok(alpha>=star.alpha*.879&&alpha<=star.alpha*1.121)}}report.stars={total:stars.length,twinkling:stars.filter(s=>s.twinkle).length,cycles:'4–10 s',amplitude:'12%'};
assert.deepEqual(mirAssembly(3,.55),[1,1,1]);const museum=await readFile('src/museum.js','utf8');assert.ok(!museum.includes('stars(v.scene)'));assert.ok(!museum.includes("key==='mars3'?modelBounds"));assert.ok(!museum.includes('narrow()?.16:.38'));assert.ok(museum.includes('sky.setPaused(paused||motion.matches)'));
await writeFile('qa/pass5/logic-results.json',JSON.stringify(report,null,2)+'\n');console.log(report);
