import * as T from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {sputnik,vostok,luna9,venera9,voskhod2,lunokhod1,mars3,salyut1,mir,mesh} from './models.js';
import {clamp,smooth,sampleSteps,mirAssembly} from './story-state.js';
const motion=matchMedia('(prefers-reduced-motion: reduce)');
const narrow=()=>innerWidth<761;
const asset=name=>window.__MUSEUM_ASSETS__?.[name]||new URL(`assets/${name}`,document.baseURI).href;
const orbitPoint=p=>new T.Vector3(3.25*Math.cos(p),.87*Math.sin(p),3.08*Math.sin(p));
const SUN=new T.Vector3(-6,2.4,3).normalize();
const factories={sputnik,vostok,luna9,venera9,voskhod2,lunokhod1,mars3,salyut1,mir};
let masks,renderer,environment,environmentTarget,observer,views=[],raf=0,last=0,time=0,phase=2.35,orbits=0,paused=false,lost=false,disposed=false,quality=1,slow=0,frames=0,cpu=0,qa=null;
const textureCache=new Map(),ray=new T.Raycaster();
const labels={earth:'Земля и Спутник-1',sputnik:'Спутник-1',human:'Корабли «Восток» и «Восход-2»',moon:'Луна и автоматические аппараты',venus:'Венера и «Венера-9»',mars:'Марс и «Марс-3»',stations:'«Салют-1» и «Мир»'};
const planetInfo={earth:{file:'earth-day.jpg',tilt:23.44,spin:.013,roughness:.9},moon:{file:'moon.jpg',tilt:6.68,spin:.010,roughness:.94},venus:{file:'venus.jpg',tilt:2.64,spin:-.008,roughness:.99},mars:{file:'mars.jpg',tilt:25.19,spin:.015,roughness:.92}};
function wake(){if(!raf&&!document.hidden&&!lost&&!disposed)raf=requestAnimationFrame(tick)}
function mount(){
 document.querySelector('#earth')?.remove();const earthHost=document.querySelector('.earth-stage');earthHost.dataset.scene='earth';
 document.querySelector('.earth-hint').innerHTML='ВРАЩАЙТЕ ПЛАНЕТУ · ПРОКРУЧИВАЙТЕ ДАЛЬШЕ <span>NASA BLUE MARBLE / ХУДОЖЕСТВЕННЫЙ МАСШТАБ</span>';
 document.querySelector('.orbital-label').innerHTML='ПС-1 / СПУТНИК<br><span>04 ОКТЯБРЯ 1957</span><br><span class="orbit-readout">ОРБИТАЛЬНЫЙ ПОЛЁТ</span>';
 for(const host of document.querySelectorAll('[data-scene]')){
  const kind=host.dataset.scene,el=document.createElement('div');el.className=`webgl-view view-${kind}`;el.id=kind==='earth'?'earth':`${kind}-model`;el.tabIndex=0;el.setAttribute('role','group');el.setAttribute('aria-label',labels[kind]+'. Перетаскивание и стрелки вращают объект. Плюс и минус — масштаб. Колесо прокручивает страницу.');
  el.innerHTML='<span class="view-status">Подготовка сцены…</span><div class="viewer-tools"><span class="drag-label">↔ ВРАЩАТЬ</span><button type="button" aria-label="Вернуть удобный ракурс">↺</button></div>';host.prepend(el);
  const section=kind==='earth'?document.querySelector('#home'):host.closest('.narrative');const readout=document.createElement('div');readout.className='model-readout';readout.hidden=true;readout.setAttribute('aria-live','polite');host.append(readout);
  const v={kind,host,el,section,steps:[...section.querySelectorAll('.narrative-step')],scene:null,camera:null,ready:false,building:false,active:false,items:new Map(),planet:null,stage:-1,local:0,progress:0,manual:new T.Quaternion(),manualY:0,manualX:0,velocity:new T.Vector2(),drag:false,pointer:null,lastInput:-99,idle:1,zoom:1,targetZoom:1,readout,hover:null,selectedKey:'',rect:null};views.push(v);bind(v);
 }
 const toggle=document.createElement('button');toggle.id='motion-toggle';toggle.className='motion-control';toggle.type='button';toggle.textContent='Ⅱ Пауза движения';toggle.setAttribute('aria-pressed','false');toggle.addEventListener('click',()=>{paused=!paused;toggle.textContent=paused?'▷ Продолжить движение':'Ⅱ Пауза движения';toggle.setAttribute('aria-pressed',String(paused));wake()});document.body.append(toggle);
}
function interact(v){v.lastInput=time;v.idle=0;wake()}
function rotate(v,dx,dy){v.manualY-=dx;v.manualX=T.MathUtils.clamp(v.manualX+dy,-1.1,1.1);v.manual.setFromEuler(new T.Euler(v.manualX,v.manualY,0,'YXZ'))}
function bind(v){
 v.el.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;v.pointer={x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,t:performance.now(),id:e.pointerId};v.drag=true;v.velocity.set(0,0);v.el.setPointerCapture(e.pointerId);v.el.classList.add('dragging');interact(v)});
 v.el.addEventListener('pointermove',e=>{
  if(v.drag&&v.pointer){const p=v.pointer,dt=Math.max(.008,(performance.now()-p.t)/1000),dx=(e.clientX-p.x)*.005,dy=e.pointerType==='touch'?0:(e.clientY-p.y)*.0038;rotate(v,dx,dy);v.velocity.set(T.MathUtils.clamp(-dx/dt,-1.1,1.1),T.MathUtils.clamp(dy/dt,-.7,.7));p.x=e.clientX;p.y=e.clientY;p.t=performance.now();interact(v)}else if(e.pointerType!=='touch')pick(v,e,false);
 });
 const up=e=>{if(v.pointer&&Math.hypot(e.clientX-v.pointer.startX,e.clientY-v.pointer.startY)<6)pick(v,e,true);v.drag=false;v.pointer=null;v.el.classList.remove('dragging');interact(v)};
 v.el.addEventListener('pointerup',up);v.el.addEventListener('pointercancel',()=>{v.drag=false;v.pointer=null;v.velocity.set(0,0);v.el.classList.remove('dragging');interact(v)});
 v.el.addEventListener('pointerleave',()=>{v.el.classList.remove('over-hotspot');v.readout.hidden=true});
 v.el.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','=','-'].includes(e.key))return;e.preventDefault();e.stopPropagation();rotate(v,e.key==='ArrowLeft'?.12:e.key==='ArrowRight'?-.12:0,e.key==='ArrowUp'?.1:e.key==='ArrowDown'?-.1:0);if(['+','=','-'].includes(e.key))v.targetZoom=T.MathUtils.clamp(v.targetZoom*(e.key==='-'?1.1:.9),.8,1.2);interact(v)});
 v.el.querySelector('button').addEventListener('click',()=>{v.manual.identity();v.manualX=v.manualY=0;v.velocity.set(0,0);v.targetZoom=1;interact(v)});
 // No wheel handler: native vertical scroll remains untouched.
}
function pick(v,e,click){
 if(!v.ready)return;const r=v.el.getBoundingClientRect();ray.setFromCamera(new T.Vector2((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1),v.camera);
 const hits=ray.intersectObjects(v.scene.children,true).filter(h=>h.object.isMesh&&isVisible(h.object));const first=hits[0],h=first?.object.userData?.hotspot?first.object.userData:null;v.el.classList.toggle('over-hotspot',!!h);
 if(h){v.readout.hidden=false;v.readout.innerHTML=`<strong>${h.title}</strong><p>${h.text}</p>`;if(click)interact(v)}else if(!click)v.readout.hidden=true;
}
function isVisible(o){for(let p=o;p;p=p.parent)if(!p.visible)return false;return true}
function light(v,planet=false){const scene=v.scene;scene.environment=environment;scene.add(new T.AmbientLight(0x91aacc,planet?.045:.25));const sun=new T.DirectionalLight(0xfff1dc,planet?2.7:3);sun.position.copy(SUN).multiplyScalar(12);if(v.kind==='earth'){sun.castShadow=true;sun.shadow.mapSize.set(narrow()?512:1024,narrow()?512:1024);Object.assign(sun.shadow.camera,{left:-4.5,right:4.5,top:4.5,bottom:-4.5,near:1,far:25});sun.shadow.bias=-.0005;sun.shadow.normalBias=.012}scene.add(sun);if(!planet){const rim=new T.DirectionalLight(0x93bddc,.8);rim.position.set(4,2,-4);scene.add(rim)}}
function stars(scene){let seed=31;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};for(let l=0;l<3;l++){const a=[];for(let i=0;i<(narrow()?65:150)/(l+1);i++)a.push((rnd()-.5)*50,(rnd()-.5)*32,-14-rnd()*25-l*12);const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(a,3));scene.add(new T.Points(g,new T.PointsMaterial({color:0xa6bbc9,size:.023+l*.014,transparent:true,opacity:.5,depthWrite:false})))}}
async function loadTexture(name,color=true){if(!textureCache.has(name))textureCache.set(name,new T.TextureLoader().loadAsync(asset(name)).then(t=>{t.colorSpace=color?T.SRGBColorSpace:T.NoColorSpace;t.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());return t}));return textureCache.get(name)}
function atmosphere(parent,r,color,strength=.4){const a=new T.Mesh(new T.SphereGeometry(r,64,40),new T.ShaderMaterial({side:T.BackSide,transparent:true,depthTest:true,depthWrite:false,uniforms:{sun:{value:SUN},tint:{value:new T.Color(color)},strength:{value:strength}},vertexShader:'varying vec3 n;varying vec3 p;void main(){vec4 w=modelMatrix*vec4(position,1.);p=w.xyz;n=normalize(mat3(modelMatrix)*normal);gl_Position=projectionMatrix*viewMatrix*w;}',fragmentShader:'uniform vec3 sun;uniform vec3 tint;uniform float strength;varying vec3 n;varying vec3 p;void main(){vec3 v=normalize(cameraPosition-p);float rim=pow(1.-abs(dot(normalize(n),v)),3.);float day=smoothstep(-.28,.55,dot(normalize(n),sun));gl_FragColor=vec4(tint,rim*(.05+strength*day));}'}));parent.add(a);return a}
async function planet(v){
 const info=planetInfo[v.kind],rig=new T.Group(),composition=new T.Group(),axis=new T.Group(),surface=new T.Group();rig.add(composition);composition.add(axis);axis.rotation.z=T.MathUtils.degToRad(info.tilt);axis.add(surface);v.scene.add(rig);v.planet={rig,composition,axis,surface,body:null,clouds:null,spin:0};
 const geo=new T.SphereGeometry(2,80,56),mat=new T.MeshStandardMaterial({roughness:info.roughness,metalness:0,envMap:environment,envMapIntensity:.02}),body=mesh(geo,mat,surface);body.castShadow=v.kind==='earth';body.receiveShadow=false;v.planet.body=body;surface.rotation.y=v.kind==='earth'?3.9:1.4;
 if(v.kind==='earth'){const cm=new T.MeshStandardMaterial({color:0xfffbf1,roughness:1,envMap:environment,envMapIntensity:.015,transparent:true,opacity:.87,depthTest:true,depthWrite:false}),clouds=mesh(new T.SphereGeometry(2.009,80,56),cm,surface);clouds.castShadow=false;clouds.receiveShadow=false;v.planet.clouds=clouds;atmosphere(rig,2.035,0x398aca,.4);cm.alphaMap=await loadTexture('earth-clouds.jpg',false);cm.needsUpdate=true}
 if(v.kind==='venus')atmosphere(rig,2.035,0xd1a573,.27);
 if(v.kind==='mars')atmosphere(rig,2.016,0xb78b73,.1);
 mat.map=await loadTexture(info.file);if(v.kind==='moon'||v.kind==='mars'){mat.bumpMap=mat.map;mat.bumpScale=v.kind==='moon'?.075:.026}mat.needsUpdate=true;
 if(v.kind==='earth'){
  const sat=ensure(v,'sputnik');sat.rig.scale.setScalar(.27);v.satellite=sat.rig;sat.object.hotspots.forEach(h=>h.anchor.removeFromParent());sat.object.root.traverse(o=>{if(o.isMesh){o.material=o.material.clone();o.material.envMap=environment;o.material.envMapIntensity=.22}});
  const pts=Array.from({length:241},(_,i)=>orbitPoint(i/240*Math.PI*2));v.orbit=new T.LineLoop(new T.BufferGeometry().setFromPoints(pts),new T.LineBasicMaterial({color:0x7b8e9f,transparent:true,opacity:.3,depthTest:true,depthWrite:false}));v.scene.add(v.orbit);
 }
}
function ensure(v,key){if(v.items.has(key))return v.items.get(key);const object=factories[key](),rig=new T.Group(),pose=new T.Group();rig.add(pose);pose.add(object.root);v.scene.add(rig);const item={object,rig,pose};v.items.set(key,item);return item}
async function buildView(v){if(v.ready||v.building||disposed)return;v.building=true;v.scene=new T.Scene();v.camera=new T.PerspectiveCamera(38,1,.05,100);light(v,!!planetInfo[v.kind]);stars(v.scene);try{
 if(planetInfo[v.kind])await planet(v);else ensure(v,v.kind==='human'?'vostok':v.kind==='stations'?'salyut1':'sputnik');
 v.ready=true;v.el.dataset.ready='true';v.el.querySelector('.view-status').textContent='ВРАЩЕНИЕ · ПРОКРУТКА ВНИЗ';wake();
 }catch(e){v.el.dataset.ready='error';v.el.querySelector('.view-status').textContent='3D не загрузилось — рассказ доступен';console.error('Scene load',v.kind,e)}}
function state(v){if(!v.steps.length){const r=v.section.getBoundingClientRect();return {index:0,local:clamp(-r.top/Math.max(1,r.height-innerHeight*.2)),progress:clamp(-r.top/r.height)}}const focus=narrow()?Math.min(innerHeight*.68,innerHeight-110):innerHeight*.55;return sampleSteps(v.steps.map(el=>el.getBoundingClientRect()),focus)}
function caption(v,text,year){const c=v.section.querySelector('.scene-caption'),y=v.section.querySelector('.scene-epoch');if(c)c.textContent=text;if(y)y.textContent=year||'';const step=v.section.querySelector('.scene-step');if(step)step.textContent=String(v.stage+1).padStart(2,'0')+' / '+String(v.steps.length).padStart(2,'0')}
function show(v,key){for(const [k,item] of v.items)item.rig.visible=k===key;v.selectedKey=key;return key?ensure(v,key):null}
function poseItem(v,item,scale=1,y=0,angle=0){if(!item)return;item.rig.visible=true;item.rig.scale.setScalar(scale);item.rig.position.set(0,y,0);item.rig.quaternion.copy(v.manual);item.pose.rotation.set(.07,angle,0)}
function update(v,dt){
 const sample=state(v);v.stage=sample.index;v.local=sample.local;v.progress=sample.progress;v.el.dataset.stage=String(v.stage);v.el.dataset.progress=v.progress.toFixed(4);v.el.dataset.manual=v.manualY.toFixed(3);
 const quiet=motion.matches,animate=!quiet&&!paused,p=smooth(v.local);v.steps.forEach((e,i)=>e.classList.toggle('is-current',i===v.stage));
 if(!v.drag&&animate){v.manualY+=v.velocity.x*dt;v.manualX=T.MathUtils.clamp(v.manualX+v.velocity.y*dt,-1.1,1.1);v.velocity.multiplyScalar(Math.exp(-5*dt));v.manual.setFromEuler(new T.Euler(v.manualX,v.manualY,0,'YXZ'))}else if(quiet||paused)v.velocity.set(0,0);
 v.idle=T.MathUtils.damp(v.idle,!v.drag&&time-v.lastInput>2.5?1:0,4,dt);v.zoom=quiet?v.targetZoom:T.MathUtils.damp(v.zoom,v.targetZoom,6,dt);
 if(v.planet){if(animate)v.planet.surface.rotation.y+=dt*planetInfo[v.kind].spin*v.idle;v.planet.rig.quaternion.copy(v.manual);if(v.planet.clouds&&animate)v.planet.clouds.rotation.y+=dt*.0011*v.idle;v.planet.composition.rotation.y=quiet?0:smooth(v.progress)*.65;v.el.dataset.spin=v.planet.surface.rotation.y.toFixed(5);v.el.dataset.idle=v.idle.toFixed(3);v.planet.rig.visible=true;v.planet.rig.scale.setScalar(1);v.planet.rig.position.set(0,0,0)}
 let distance=8.2,yaw=.0,pitch=.07,focusY=0;const stage=v.stage,local=v.local;const year=v.steps[stage]?.dataset.year||'';
 if(v.kind==='earth'){
  distance=8.2+(quiet?0:smooth(v.progress)*2.4);v.satellite.visible=true;v.satellite.position.copy(orbitPoint(phase));v.satellite.rotation.set(.05,phase*.235,-.6);v.el.dataset.phase=String(Math.round(phase*180/Math.PI));const label=document.querySelector('.orbit-readout');if(label)label.textContent='ФАЗА '+String(Math.round(phase*180/Math.PI)).padStart(3,'0')+'° · МАСШТАБ УСЛОВНЫЙ';
 }else if(v.kind==='sputnik'){
  const item=show(v,'sputnik');item.object.root.position.y=.85;distance=stage===1?1.8:6;focusY=stage===1?.85*smooth(local*3):stage===2?.85*(1-smooth(local*3)):0;poseItem(v,item,1,0,quiet?.3:.3+stage*.65+p*.25);caption(v,stage===1?'СПУТНИК-1 / СФЕРИЧЕСКИЙ КОРПУС':stage===2?'СПУТНИК-1 / АНТЕННЫ И РАДИОСВЯЗЬ':'СПУТНИК-1 / РЕКОНСТРУКЦИЯ',year);
 }else if(v.kind==='human'){
  const key=stage===2?'voskhod2':'vostok',item=show(v,key);distance=stage===2?10.1:6.4;yaw=-.1;poseItem(v,item,1,0,quiet?.2:.2+stage*.2+p*.35);if(key==='vostok')item.object.eva.visible=false;caption(v,stage===2?'«ВОСХОД-2» / ШЛЮЗ «ВОЛГА» И ВЫХОД ЛЕОНОВА':stage===1?'«ВОСТОК-6» / ТЕХНИЧЕСКАЯ РЕКОНСТРУКЦИЯ':'«ВОСТОК-1» / ТЕХНИЧЕСКАЯ РЕКОНСТРУКЦИЯ',year);
 }else if(v.kind==='moon'){
  let key=stage===3?'luna9':stage===5?'lunokhod1':null;const item=show(v,key);if(key){v.planet.rig.scale.setScalar(.55);v.planet.rig.position.set(0,-2.9,-1.8);poseItem(v,item,stage===5?1.1:1.35,-.1,quiet?.25:.25+p*.3);distance=7.5}else{distance=stage===0?8.1:stage===2?6.9:7.6;v.planet.rig.position.y=quiet?0:(p-.5)*.15;v.planet.composition.rotation.y+=stage===2?Math.PI*(quiet?1:smooth(local*3)):0}
  caption(v,key==='luna9'?'«ЛУНА-9» / РАСКРЫТАЯ ПОСАДОЧНАЯ КАПСУЛА':key==='lunokhod1'?'«ЛУНОХОД-1» / ВОСЕМЬ КОЛЁС И СОЛНЕЧНАЯ КРЫШКА':stage===2?'ЛУНА / ОБРАТНОЕ ПОЛУШАРИЕ':stage===4?'«ЛУНА-16» / ДОСТАВКА ГРУНТА · ПОВЕРХНОСТЬ ЛУНЫ':'ЛУНА / КАРТА ПОВЕРХНОСТИ',year);
 }else if(v.kind==='venus'){
  const key=stage===2?'venera9':null,item=show(v,key);if(item){v.planet.rig.scale.setScalar(.57);v.planet.rig.position.set(0,-3,-2);poseItem(v,item,1.25,-.1,quiet?.2:.2+p*.3);distance=7.8}else distance=8.1-(quiet?0:p*.35);
  caption(v,item?'«ВЕНЕРА-9» / ПОСАДОЧНЫЙ АППАРАТ · РЕКОНСТРУКЦИЯ':'ВЕНЕРА / ОБЛАЧНАЯ ОБОЛОЧКА',year);
 }else if(v.kind==='mars'){
  const key=stage>0?'mars3':null,item=show(v,key);distance=8.3;
  if(item){v.planet.rig.scale.setScalar(.65);v.planet.rig.position.set(0,-3.2,-2);poseItem(v,item,1.4,stage===1?(quiet?.3:1.05-p*.95):-.2,quiet?.2:.2+p*.12);item.object.parachute.visible=stage===1&&!quiet;item.object.petals.visible=stage>=2;item.object.hotspots[1].anchor.visible=stage>=2;distance=stage===1?10.7:7.3}
  caption(v,stage===0?'МАРС / КАРТА ПОВЕРХНОСТИ':stage===1?'«МАРС-3» / УСЛОВНАЯ РЕКОНСТРУКЦИЯ СПУСКА':stage===2?'«МАРС-3» / МЯГКАЯ ПОСАДКА':'«МАРС-3» / ПЕРЕДАЧА ПРЕКРАТИЛАСЬ',year);
  const signal=v.section.querySelector('.signal-status');if(signal)signal.textContent=stage===3?'СИГНАЛ ПРЕКРАТИЛСЯ':stage===2?'ПЕРЕДАЧА ≈20 СЕКУНД':'РЕКОНСТРУКЦИЯ';
 }else if(v.kind==='stations'){
  const key=stage===0?'salyut1':'mir',item=show(v,key);distance=stage===0?9.5:13.5;poseItem(v,item,1,0,quiet?.15:.15+p*.3);
  if(key==='mir'){const amounts=mirAssembly(stage,quiet?1:local);item.object.modules.forEach((m,i)=>{m.visible=amounts[i]>.001;m.scale.setScalar(Math.max(.001,amounts[i]));m.userData.amount=amounts[i]});item.object.hotspots.forEach((h,i)=>h.anchor.visible=i===0||i===1&&amounts[0]>.3||i===2&&(amounts[1]>.3||amounts[2]>.3));v.el.dataset.modules=amounts.map(x=>x.toFixed(3)).join(',')}
  caption(v,stage===0?'«САЛЮТ-1» / ПЕРВАЯ ОРБИТАЛЬНАЯ СТАНЦИЯ':stage===1?'«МИР» / БАЗОВЫЙ БЛОК':stage===2?'«МИР» / БАЗОВЫЙ БЛОК И «КВАНТ»':'«МИР» / «КВАНТ-2» И «КРИСТАЛЛ» · ДО 1991 ГОДА',year);
 }
 if(!quiet&&v.steps.length){const plans={sputnik:[6,1.8,6],human:[6.4,6.4,10.1],moon:[8.1,7.6,6.9,7.5,7.6,7.5],venus:[8.1,8.1,7.8,8.1],mars:[8.3,10.7,7.3,7.3],stations:[9.5,13.5,13.5,13.5]};const previous=plans[v.kind]?.[Math.max(0,stage-1)]??distance;distance=T.MathUtils.lerp(previous,distance,smooth(local*3));}
 if(quiet){pitch=.06;distance+=.15}else{pitch+=v.progress*.035}
 v.el.dataset.craft=v.selectedKey||'';v.el.dataset.distance=distance.toFixed(3);
 const r=v.rect;v.camera.position.set(Math.sin(yaw)*distance*v.zoom,focusY+Math.sin(pitch)*distance*v.zoom,Math.cos(yaw)*Math.cos(pitch)*distance*v.zoom);v.camera.lookAt(0,focusY,0);v.camera.aspect=r.width/r.height;v.camera.updateProjectionMatrix();v.scene.updateMatrixWorld(true);
}
function resize(){if(!renderer)return;renderer.setPixelRatio(Math.min(devicePixelRatio||1,narrow()?1.2:1.6)*quality);renderer.setSize(innerWidth,innerHeight,false);wake()}
function tick(now){raf=0;if(disposed||lost||document.hidden)return;const dt=Math.min(.05,last?(now-last)/1000:1/60);last=now;time+=dt;
 const visible=views.filter(v=>v.active&&v.ready);if(visible.length&&!motion.matches&&!paused){phase+=dt*.17;if(phase>=Math.PI*2){phase-=Math.PI*2;orbits++}}
 const start=performance.now();
 for(const v of views){if(!v.mask)continue;const r=v.host.closest('.narrative-visual').getBoundingClientRect();v.mask.hidden=r.bottom<0||r.top>innerHeight;Object.assign(v.mask.style,{left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px'});}
 renderer.setScissorTest(false);renderer.setClearColor(0,0);renderer.clear();renderer.setScissorTest(true);let calls=0,triangles=0,count=0;
 for(const v of visible){const r=v.el.getBoundingClientRect(),section=v.section.getBoundingClientRect();if(r.bottom<0||r.top>innerHeight||section.bottom<80)continue;v.rect=r;update(v,dt);const l=Math.max(0,r.left),b=Math.max(0,innerHeight-r.bottom),right=Math.min(innerWidth,r.right),top=Math.min(innerHeight,innerHeight-r.top);renderer.setViewport(r.left,innerHeight-r.bottom,r.width,r.height);renderer.setScissor(l,b,Math.max(0,right-l),Math.max(0,top-b));renderer.clear(true,true,true);renderer.render(v.scene,v.camera);calls+=renderer.info.render.calls;triangles+=renderer.info.render.triangles;count++}
 renderer.setScissorTest(false);frames++;cpu+=performance.now()-start;if(count&&dt>.036){if(++slow>120&&quality>.65){quality=Math.max(.65,quality-.15);slow=0;resize()}}else slow=Math.max(0,slow-1);
 if(qa&&(frames%15===0||paused||motion.matches))qa.querySelector('output').textContent=JSON.stringify({contexts:1,activeViews:count,calls,triangles,dpr:renderer.getPixelRatio(),geometries:renderer.info.memory.geometries,textures:renderer.info.memory.textures,frames,meanCpuMs:+(cpu/frames).toFixed(2),phase:Math.round(phase*180/Math.PI),completedOrbits:orbits,paused,reducedMotion:motion.matches,contextLost:lost,scenes:visible.map(v=>({kind:v.kind,stage:v.stage,progress:+v.progress.toFixed(3),manual:+v.manualY.toFixed(3),idle:+v.idle.toFixed(3)}))},null,2);
 const unsettled=visible.some(v=>v.drag||v.velocity.length()>.002||Math.abs(v.zoom-v.targetZoom)>.001);if((count&&!paused&&!motion.matches)||unsettled)raf=requestAnimationFrame(tick);
}
async function depthAudit(){
 const v=views[0];if(!v.ready)return;const target=new T.WebGLRenderTarget(256,256),pixels=new Uint8Array(256*256*4),white=new T.MeshBasicMaterial({color:0xffffff}),red=new T.MeshBasicMaterial({color:0xff0000}),saved=[];
 const old={phase,manual:v.manual.clone(),my:v.manualY,mx:v.manualX,paused,body:v.planet.body.material,cloud:v.planet.clouds.visible,orbit:v.orbit.visible};v.planet.body.material=white;v.planet.clouds.visible=false;v.orbit.visible=false;v.satellite.traverse(o=>{if(o.isMesh){saved.push([o,o.material]);o.material=red}});paused=true;const result=[];
 try{renderer.setScissorTest(false);renderer.setRenderTarget(target);for(const angle of [0,.55,-.65])for(const orbitalPhase of [Math.PI/2,Math.PI*1.5]){
  phase=orbitalPhase;v.manualY=angle;v.manualX=0;v.manual.setFromEuler(new T.Euler(0,angle,0));v.rect={width:256,height:256};update(v,0);const counts=[];
  for(const visible of [false,true]){v.planet.rig.visible=visible;renderer.setClearColor(0x000000,1);renderer.clear();renderer.render(v.scene,v.camera);renderer.readRenderTargetPixels(target,0,0,256,256,pixels);let n=0;for(let i=0;i<pixels.length;i+=4)if(pixels[i]>120&&pixels[i+1]<50&&pixels[i+2]<50)n++;counts.push(n)}result.push({rotation:angle,phase:Math.round(orbitalPhase*180/Math.PI),withoutEarth:counts[0],withEarth:counts[1]});
 }}finally{v.planet.rig.visible=true;v.planet.body.material=old.body;v.planet.clouds.visible=old.cloud;v.orbit.visible=old.orbit;saved.forEach(([o,m])=>o.material=m);phase=old.phase;v.manual.copy(old.manual);v.manualY=old.my;v.manualX=old.mx;paused=old.paused;renderer.setRenderTarget(null);target.dispose();white.dispose();red.dispose();wake()}
 qa.querySelector('pre').textContent=JSON.stringify({passed:result.filter(r=>r.phase===270&&r.withoutEarth>0&&r.withEarth===0).length===3&&result.filter(r=>r.phase===90&&r.withEarth>0).length===3,results:result},null,2);
}
function diagnostics(){if(!new URLSearchParams(location.search).has('qa'))return;qa=document.createElement('details');qa.className='graphics-qa';qa.innerHTML='<summary>Проверка 3D</summary><button class="depth-audit">Проверить глубину</button><output></output><pre></pre>';document.body.append(qa);qa.querySelector('button').addEventListener('click',depthAudit)}
export async function initMuseum(){
 mount();try{renderer=new T.WebGLRenderer({alpha:true,antialias:true,powerPreference:'high-performance'})}catch(e){document.documentElement.classList.add('webgl-unavailable');document.querySelectorAll('.view-status').forEach(e=>e.textContent='Текст и источники доступны без WebGL');return}
 renderer.domElement.className='webgl-layer';renderer.domElement.setAttribute('aria-hidden','true');renderer.autoClear=false;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.03;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;document.body.append(renderer.domElement);
 masks=document.createElement('div');masks.className='scene-mask-layer';masks.setAttribute('aria-hidden','true');for(const v of views){if(v.kind==='earth')continue;v.mask=document.createElement('div');v.mask.className='scene-mask mask-'+v.kind;v.mask.hidden=true;masks.append(v.mask)}document.body.append(masks);
 const pmrem=new T.PMREMGenerator(renderer),room=new RoomEnvironment();environmentTarget=pmrem.fromScene(room,.02);environment=environmentTarget.texture;room.dispose();pmrem.dispose();resize();
 observer=new IntersectionObserver(entries=>{for(const e of entries){const v=views.find(v=>v.el===e.target);v.active=e.isIntersecting;if(e.isIntersecting)buildView(v)}wake()},{rootMargin:'200px'});views.forEach(v=>observer.observe(v.el));
 addEventListener('scroll',wake,{passive:true});addEventListener('resize',resize);motion.addEventListener('change',wake);document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);raf=0;last=0}else wake()});
 renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;cancelAnimationFrame(raf);raf=0;document.documentElement.classList.add('webgl-unavailable')});renderer.domElement.addEventListener('webglcontextrestored',()=>{lost=false;document.documentElement.classList.remove('webgl-unavailable');resize();wake()});
 addEventListener('pagehide',e=>{if(e.persisted)return;disposed=true;cancelAnimationFrame(raf);observer.disconnect();const geos=new Set(),mats=new Set(),textures=new Set();views.forEach(v=>v.scene?.traverse(o=>{if(o.geometry)geos.add(o.geometry);for(const m of Array.isArray(o.material)?o.material:[o.material])if(m){mats.add(m);Object.values(m).forEach(t=>{if(t?.isTexture)textures.add(t)})}}));geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());environmentTarget.dispose();renderer.dispose()});diagnostics();wake();
}
