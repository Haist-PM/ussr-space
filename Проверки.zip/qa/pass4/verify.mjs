import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import * as T from 'three';
import * as models from '../../src/models.js';
import {applyScreenRotation,nearestMarker,fitDistance,modelBounds,projectHotspot} from '../../src/interaction.js';
import {sceneBlend,mirAssembly,sampleSteps,planetComposition} from '../../src/story-state.js';
const results={browserTested:false,rotation:[],fitting:[],markers:[],assembly:[],transitions:[]};
// Exercise screen directions, not Euler signs, for upright and tilted camera/object bases.
for(const tilt of [0,.6,1.5]){
 const camera=new T.PerspectiveCamera(38,1,.05,100);camera.position.set(1,2,9);camera.lookAt(0,0,0);camera.updateMatrixWorld(true);
 const q=new T.Quaternion().setFromEuler(new T.Euler(.3,tilt,-.72)),point=new T.Vector3(0,0,1).applyQuaternion(camera.quaternion),local=point.clone().applyQuaternion(q.clone().invert()),start=local.clone().applyQuaternion(q).project(camera);
 for(const [dx,dy] of [[.1,0],[-.1,0],[0,.1],[0,-.1]]){const next=local.clone().applyQuaternion(applyScreenRotation(q.clone(),dx,dy,camera.quaternion)).project(camera);if(dx)assert.equal(Math.sign(next.x-start.x),Math.sign(dx));if(dy)assert.equal(Math.sign(next.y-start.y),-Math.sign(dy));}
 results.rotation.push({tilt,allDirections:true});
}
// Hit areas are square, ties resolve by stable detail index, hidden markers cannot win.
const markers=[{index:1,x:100,y:100,visible:true},{index:0,x:110,y:100,visible:true},{index:2,x:103,y:100,visible:false}];
assert.equal(nearestMarker(markers,105,100,32).index,0);assert.equal(nearestMarker(markers,97,100,32).index,1);assert.equal(nearestMarker(markers,78,78,44).index,1);assert.equal(nearestMarker(markers,77,77,44),null);
// Model bounds include the widest attachments. Test every orientation against the frustum.
for(const key of ['sputnik','vostok','voskhod2','luna9','lunokhod1','venera9','mars3','salyut1','mir']){
 const object=models[key]();if(key==='mars3')object.parachute.visible=true;
 const rig=new T.Group(),pose=new T.Group(),centered=new T.Group();rig.add(pose);pose.add(centered);centered.add(object.root);rig.updateMatrixWorld(true);
 const allMeshes=[];object.root.traverse(o=>{if(o.isMesh&&!o.userData.hotspot)allMeshes.push(o)});const visible=o=>{for(let p=o;p;p=p.parent)if(!p.visible)return false;return true};
 for(const h of object.hotspots){h.dot.visible=false;const point=h.anchor.getWorldPosition(new T.Vector3());h.surface=allMeshes.filter(visible).map(o=>({o,d:new T.Box3().setFromObject(o).distanceToPoint(point)})).sort((a,b)=>a.d-b.d)[0]?.o;}
 const bounds=modelBounds(object.root);centered.position.copy(bounds.center).negate();rig.scale.setScalar(2/bounds.radius);
 let cases=0;
 for(const [width,height] of [[1000,800],[724,574],[636,300],[390,270],[390,135]])for(const [x,y,z] of [[0,.2,0],[1.2,1.9,.6],[-1.5,-2.6,.9],[2.8,3.1,-.5]]){
  const camera=new T.PerspectiveCamera(38,width/height,.05,100),d=Math.max(8.4,fitDistance(2.02,width/height));camera.position.set(0,Math.sin(.055)*d,Math.cos(.055)*d);camera.lookAt(0,0,0);camera.updateMatrixWorld(true);rig.quaternion.setFromEuler(new T.Euler(x,y,z));rig.updateMatrixWorld(true);
  for(const mesh of allMeshes.filter(visible)){mesh.geometry.computeBoundingBox();const b=mesh.geometry.boundingBox;for(const px of [b.min.x,b.max.x])for(const py of [b.min.y,b.max.y])for(const pz of [b.min.z,b.max.z]){const point=new T.Vector3(px,py,pz).applyMatrix4(mesh.matrixWorld).project(camera);assert.ok(Math.abs(point.x)<.83&&Math.abs(point.y)<.83,key+' clipped');}}cases++;
 }
 results.fitting.push({key,cases,fit:true});
 const camera=new T.PerspectiveCamera(38,700/650,.05,100),d=Math.max(8.4,fitDistance(2.02,700/650));camera.position.set(0,Math.sin(.055)*d,Math.cos(.055)*d);camera.lookAt(0,0,0);camera.updateMatrixWorld(true);rig.quaternion.identity();pose.rotation.set(.07,.35,0);rig.updateMatrixWorld(true);
 const front=object.hotspots.map(h=>projectHotspot(h,{camera,width:700,height:650,occluders:allMeshes.filter(visible),radius:2}));assert.ok(front.some(h=>h.visible),key+' has no usable front marker');
 rig.rotation.y=Math.PI;rig.updateMatrixWorld(true);const back=object.hotspots.map(h=>projectHotspot(h,{camera,width:700,height:650,occluders:allMeshes.filter(visible),radius:2}));assert.equal(back.filter(h=>h.visible).length,0,key+' has a back-side marker');results.markers.push({key,front:front.filter(h=>h.visible).length,back:0});
}
// A genuine obstruction must hide a marker; a tiny embedding in its own surface is tolerated.
{
 const surface=new T.Mesh(new T.BoxGeometry(1,1,.1),new T.MeshBasicMaterial()),anchor=new T.Object3D();anchor.position.z=.048;surface.add(anchor);surface.updateMatrixWorld(true);const camera=new T.PerspectiveCamera(38,1,.05,100);camera.position.z=6;camera.updateMatrixWorld(true);const h={anchor,normal:new T.Vector3(0,0,1),surface};const args={camera,width:600,height:600,occluders:[surface],radius:1};assert.equal(projectHotspot(h,args).visible,true);
 const blocker=new T.Mesh(new T.BoxGeometry(1,1,.1),new T.MeshBasicMaterial());blocker.position.z=1;blocker.updateMatrixWorld(true);assert.equal(projectHotspot(h,{...args,occluders:[surface,blocker]}).visible,false);
}
// Last-stage progress is measured to the actual sticky release, including the observation tail.
for(const [viewport,visual,top,stepHeight,tail,focus] of [[1080,998,82,896,410,594],[768,686,82,638,292,422],[540,458,82,510,220,297],[844,371,65,608,270,574],[568,300,65,550,210,386]]){
 const travel=stepHeight+tail-visual-top+focus;assert.ok(travel>0);const at=amount=>sampleSteps([{top:-3000,height:stepHeight},{top:-2000,height:stepHeight},{top:-1000,height:stepHeight},{top:focus-travel*amount,height:stepHeight}],focus,{lastTravel:travel});
 const full=mirAssembly(at(.55).index,at(.55).local);assert.deepEqual(full,[1,1,1]);assert.deepEqual(mirAssembly(at(.9).index,at(.9).local),full);assert.ok(mirAssembly(at(.3).index,at(.3).local)[2]<.05);assert.deepEqual(mirAssembly(1,1),[0,0,0]);results.assembly.push({viewport,completeBeforeReleasePx:Math.round(travel*.45),reversible:true});
}
for(const kind of ['moon','venus','mars','stations','human'])for(let stage=1;stage<({moon:6,venus:4,mars:4,stations:4,human:3}[kind]);stage++){
 let last;for(let i=0;i<=100;i++){const b=sceneBlend(kind,stage,i/100);assert.ok(b.close>=0&&b.close<=1);assert.ok(Object.keys(b.weights).length<=1,'Two craft overlap');if(last)assert.ok(Math.abs(b.close-last.close)<.045);last=b;}
 assert.deepEqual(sceneBlend(kind,stage,.21),sceneBlend(kind,stage,.21));results.transitions.push({kind,stage,continuous:true,noOverlappingCraft:true});
}
for(const [kind,stage] of [['moon',3],['moon',4],['moon',5],['venus',2],['venus',3],['mars',1]])for(let i=0;i<=100;i++){
 const blend=sceneBlend(kind,stage,i/100),planet=planetComposition(blend.close);assert.ok(planet.scale>=1);for(const weight of Object.values(blend.weights)){if(weight<.001)continue;const craftRadius=2*(.45+.55*weight);assert.ok(Math.hypot(planet.y,planet.z)>planet.scale*2+craftRadius,'Craft intersects planet during transition');}
}
const css=await readFile('style.css','utf8');assert.ok(!css.includes('#07111d'));const museum=await readFile('src/museum.js','utf8');assert.ok(!museum.includes('v.manual'));assert.ok(museum.includes('touch-action:pan-y'));assert.ok(!museum.includes("addEventListener('wheel'"));
await writeFile('qa/pass4/logic-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify({rotationCases:12,modelFramingCases:180,frontAndBackMarkerCases:18,stickySizes:results.assembly.length,transitionCases:results.transitions.length,passed:true,browserTested:false}));
