// Pure scroll sampling. No timers: a given layout/position always yields the same story.
export const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
export const smooth=(x)=>{x=clamp(x);return x*x*(3-2*x)};
export function sampleSteps(rects,focus){
 let index=0;for(let i=0;i<rects.length;i++)if(rects[i].top<=focus)index=i;
 const rect=rects[index];return {index,local:clamp((focus-rect.top)/Math.max(1,rect.height)),progress:clamp((index+clamp((focus-rect.top)/Math.max(1,rect.height)))/rects.length)};
}
export function mirAssembly(stage,local){
 if(stage<2)return [0,0,0];
 if(stage===2)return [smooth(local*2+.15),0,0];
 return [1,smooth(local*3+.1),smooth((local-.35)*3)];
}
