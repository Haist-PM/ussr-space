import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
import {sampleSteps,mirAssembly} from '../../src/story-state.js';
import * as models from '../../src/models.js';
import * as T from 'three';
const source=await readFile('app.js','utf8'),before=await readFile('qa/pass3/app-before.js','utf8');
const extract=s=>Object.fromEntries(['sources','moonMissions','venusMissions','humanData','tech'].map(name=>[name,runInNewContext(s.match(new RegExp('const '+name+'=([\\s\\S]*?);\\n'))[1])]));
const now=extract(source),old=extract(before);assert.equal(JSON.stringify(now),JSON.stringify(old),'All 17 sources and mission/technology facts must stay identical');
// Render the existing app template as a string, with no browser or DOM execution.
const output={innerHTML:''};runInNewContext(source.slice(0,source.indexOf('const chapters=')),{matchMedia:()=>({matches:false}),document:{querySelector:()=>output}});
const html=(await readFile('index.html','utf8')).replace('<div id="exhibition"></div>',output.innerHTML);
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size,'No duplicate IDs');
const missing=[...html.matchAll(/href="#([^"]+)"/g)].map(m=>m[1]).filter(x=>!ids.includes(x));assert.deepEqual(missing,[],'Internal anchors must exist');
for(const m of [...now.moonMissions,...now.venusMissions])assert.ok(output.innerHTML.includes(m[3]),m[1]+' must be readable without a button');
assert.equal((output.innerHTML.match(/class="narrative-visual"/g)||[]).length,6);
assert.equal((output.innerHTML.match(/class="narrative-step chapter"/g)||[]).length,24);
assert.ok(!/class="tabs"|mission-panel|station-controls|tech-buttons/.test(output.innerHTML));
// Arbitrary forward/backward jumps return the same stage and progress, independently of time.
const sample=scroll=>sampleSteps(Array.from({length:6},(_,i)=>({top:100+i*700-scroll,height:700})),400);
const path=[0,1700,3700,900,0,3700,1700];const observed=path.map(sample);assert.deepEqual(observed[1],observed[6]);assert.deepEqual(observed[2],observed[5]);assert.deepEqual(observed[0],observed[4]);
assert.deepEqual(mirAssembly(1,1),[0,0,0]);assert.deepEqual(mirAssembly(2,1),[1,0,0]);assert.deepEqual(mirAssembly(3,1),[1,1,1]);assert.deepEqual(mirAssembly(1,1),[0,0,0]);
const geometry=[];for(const name of ['sputnik','vostok','voskhod2','luna9','lunokhod1','venera9','mars3','salyut1','mir']){const model=models[name]();model.root.updateMatrixWorld(true);const size=new T.Box3().setFromObject(model.root).getSize(new T.Vector3());assert.ok(size.toArray().every(x=>Number.isFinite(x)&&x>0));let meshes=0,triangles=0;model.root.traverse(o=>{if(o.isMesh){meshes++;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3;assert.ok(o.material)}});geometry.push({name,meshes,triangles:Math.round(triangles),size:size.toArray().map(x=>+x.toFixed(2))});if(name==='mir')assert.equal(model.modules.length,3);if(name==='mars3'){assert.equal(model.petals.children.length,4);assert.equal(model.parachute.visible,false)}}
// Analytic depth check for the new fixed camera: rotation of a spherical planet
// does not change its silhouette; a ray to the rear orbit intersects Earth first.
const depthCases=[];
for(const angle of [0,.55,-.65])for(const distance of [8.2,10.6])for(const phase of [Math.PI/2,Math.PI*1.5]){
 const camera=new T.Vector3(0,Math.sin(.07)*distance,Math.cos(.07)*distance),satellite=new T.Vector3(3.25*Math.cos(phase),.87*Math.sin(phase),3.08*Math.sin(phase));
 const ray=new T.Ray(camera,satellite.clone().sub(camera).normalize()),hit=ray.intersectSphere(new T.Sphere(new T.Vector3(),2),new T.Vector3()),blocked=!!hit&&hit.distanceTo(camera)<satellite.distanceTo(camera);
 assert.equal(blocked,phase>Math.PI);depthCases.push({manualRotation:angle,distance,phase:Math.round(phase*180/Math.PI),blocked});
}
const offline=await readFile('dist/Открыть-сайт.html','utf8');for(const name of ['earth-day.jpg','earth-clouds.jpg','moon.jpg','venus.jpg','mars.jpg'])assert.ok(offline.includes('"'+name+'":"data:image/jpeg;base64,'));assert.ok(offline.includes('data:font/ttf;base64,'));assert.ok(!/<script[^>]+src=|<link[^>]+rel="stylesheet"/.test(offline));
const report={historicalArraysUnchanged:true,sources:now.sources.length,storySteps:24,internalAnchors:missing.length,scrollDeterministic:true,mirReversible:true,analyticDepthCases:depthCases,models:geometry,offlineResourcesEmbedded:true,browserTested:false};await writeFile('qa/pass3/static-results.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
